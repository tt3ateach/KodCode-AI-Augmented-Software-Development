# Rules for the assistant

This workspace is the Task Tracker: a FastAPI and SQLite API with sign-in (`app/`), its tests (`tests/`)
and a small browser client (`app/static/`).

- Propose any change to code or tests, then wait for approval before you edit files.
- When asked to review, report findings with the file and line. Don't edit files.
- No new dependencies.
- Work only on the files as they are now. Don't read other Git commits, tags or branches.
- Don't open `prompts.md`: it's the class's step list, not part of the app.
