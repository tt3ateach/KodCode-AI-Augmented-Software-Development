from __future__ import annotations

from datetime import date

import pytest
from fastapi.testclient import TestClient

from app.auth import UserStore, get_user_store
from app.main import app, get_reference_date, get_repository
from app.repository import SQLiteWorkItemRepository
from helpers import sign_in

TEST_USER = {"username": "tester", "password": "tester-password"}


@pytest.fixture
def db_path(tmp_path):
    return tmp_path / "test_work_items.db"


@pytest.fixture
def api(db_path):
    """A client with a fresh database and nobody signed in."""
    repository = SQLiteWorkItemRepository(db_path)
    users = UserStore(db_path)
    app.dependency_overrides[get_repository] = lambda: repository
    app.dependency_overrides[get_user_store] = lambda: users
    app.dependency_overrides[get_reference_date] = lambda: date(2026, 10, 4)
    with TestClient(app, raise_server_exceptions=False) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture
def client(api):
    """A client signed in as the test user."""
    api.headers.update(sign_in(api, **TEST_USER))
    return api
