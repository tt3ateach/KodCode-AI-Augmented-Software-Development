"""Test helpers shared by the test files."""

from __future__ import annotations

from fastapi.testclient import TestClient


def sign_in(client: TestClient, username: str, password: str) -> dict[str, str]:
    """Register (if needed) and sign in; return the Authorization header for that user."""
    client.post("/auth/register", json={"username": username, "password": password})
    response = client.post("/auth/login", json={"username": username, "password": password})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}
