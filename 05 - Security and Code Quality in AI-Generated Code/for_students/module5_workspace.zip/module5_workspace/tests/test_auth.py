from __future__ import annotations

from app.auth import create_token, read_token
from helpers import sign_in


def test_register_and_sign_in(api):
    created = api.post("/auth/register", json={"username": "alice", "password": "alice-password"})
    assert created.status_code == 201
    response = api.post("/auth/login", json={"username": "alice", "password": "alice-password"})
    assert response.status_code == 200
    assert response.json()["username"] == "alice"
    assert response.json()["token_type"] == "bearer"


def test_duplicate_username_is_rejected(api):
    api.post("/auth/register", json={"username": "alice", "password": "alice-password"})
    again = api.post("/auth/register", json={"username": "alice", "password": "other-password"})
    assert again.status_code == 409


def test_wrong_password_is_rejected(api):
    api.post("/auth/register", json={"username": "alice", "password": "alice-password"})
    response = api.post("/auth/login", json={"username": "alice", "password": "wrong-password"})
    assert response.status_code == 401


def test_task_endpoints_require_sign_in(api):
    assert api.get("/work-items").status_code == 401
    assert api.post("/work-items", json={"title": "Anonymous"}).status_code == 401


def test_tampered_token_is_rejected(api):
    token = create_token("alice")
    assert read_token(token) == "alice"
    assert read_token(token[:-1] + ("0" if token[-1] != "0" else "1")) is None
    response = api.get("/work-items", headers={"Authorization": "Bearer not-a-token"})
    assert response.status_code == 401


def test_users_see_only_their_own_tasks(api):
    alice = sign_in(api, "alice", "alice-password")
    bob = sign_in(api, "bob", "bob-password")
    api.post("/work-items", json={"title": "Alice's task"}, headers=alice)
    api.post("/work-items", json={"title": "Bob's task"}, headers=bob)
    titles = [item["title"] for item in api.get("/work-items", headers=alice).json()]
    assert titles == ["Alice's task"]
