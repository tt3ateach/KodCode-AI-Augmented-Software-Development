"""Security tests written from the requirements, not from the code."""

from helpers import sign_in  # noqa: F401  (step 8 uses it)

# Step 8: paste your test below this line.
