# Task Tracker 0.5 · sign-in

Module 5 workspace: the Task Tracker from Module 4, now with accounts. Every user signs in and sees only
their own tasks.

```bash
python scripts/check_setup.py                      # once, before class
python -m uvicorn app.main:app --port 8000        # then open http://127.0.0.1:8000/
```

Demo users: `alice` / `alice-password` and `bob` / `bob-password`. `python scripts/demo_data.py` resets them.
The class steps are in `prompts.md`.
