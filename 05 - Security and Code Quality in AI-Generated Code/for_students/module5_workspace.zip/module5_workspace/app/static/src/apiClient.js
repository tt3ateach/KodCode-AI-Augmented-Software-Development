import { mapApiWorkItem, toApiCreatePayload, toApiStatus } from "./state.js";

export class UnauthorizedError extends Error {}

export function createWorkItemsApiClient(baseUrl = "", fetchImpl = fetch, getToken = () => null) {
  const root = baseUrl.replace(/\/$/, "");
  async function request(path, method = "GET", body) {
    const headers = {};
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
    const options = { method, headers };
    if (body !== undefined) {
      headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(body);
    }
    const response = await fetchImpl(root + path, options);
    if (response.status === 401) throw new UnauthorizedError("Please sign in.");
    if (!response.ok) throw new Error(`API request failed with status ${response.status}`);
    return response.status === 204 ? null : response.json();
  }
  const itemPath = id => `/work-items/${encodeURIComponent(id)}`;
  const patch = async (id, body) => mapApiWorkItem(await request(itemPath(id), "PATCH", body));
  return {
    async list() { return (await request("/work-items")).map(mapApiWorkItem); },
    async create(input) { return mapApiWorkItem(await request("/work-items", "POST", toApiCreatePayload(input))); },
    async toggleDone(id) {
      const current = await request(itemPath(id));
      return patch(id, { status: current.status === "done" ? "todo" : "done" });
    },
    async setPriority(id, priority) { return patch(id, { priority }); },
    async updateStatus(id, status) { return patch(id, { status: toApiStatus(status) }); },
    async setDueDate(id, calendarDate) { return patch(id, { due_date: calendarDate || null }); }
  };
}

export async function signIn(username, password, fetchImpl = fetch) {
  const response = await fetchImpl("/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  if (!response.ok) throw new Error("Invalid username or password.");
  return response.json();
}

export async function register(username, password, fetchImpl = fetch) {
  const response = await fetchImpl("/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  if (response.status === 409) throw new Error("That username is taken.");
  if (!response.ok) throw new Error("Could not create the account.");
  return response.json();
}
