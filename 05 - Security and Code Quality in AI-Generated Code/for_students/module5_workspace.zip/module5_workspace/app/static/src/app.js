import { UnauthorizedError, register, signIn } from "./apiClient.js";
import { createTaskService } from "./service.js";
import { DEFAULT_FILTERS, applyFilters, summarizeTasks } from "./state.js";
import { renderSummary, renderTaskList } from "./render.js";

const session = { token: null, username: null };
let service = createTaskService(() => session.token);
const filters = { ...DEFAULT_FILTERS };

const elements = {
  summary: document.querySelector("#summary"),
  taskList: document.querySelector("#task-list"),
  flash: document.querySelector("#flash-message"),
  quickAddForm: document.querySelector("#quick-add-form"),
  titleInput: document.querySelector("#task-title-input"),
  priorityInput: document.querySelector("#task-priority-input"),
  searchInput: document.querySelector("#search-input"),
  filterChips: [...document.querySelectorAll(".filter-chip")],
  dueInput: document.querySelector("#task-due-input"),
  overdueOnly: document.querySelector("#overdue-only"),
  loginForm: document.querySelector("#login-form"),
  loginUsername: document.querySelector("#login-username"),
  loginPassword: document.querySelector("#login-password"),
  registerButton: document.querySelector("#register-button"),
  signedIn: document.querySelector("#signed-in"),
  signedInName: document.querySelector("#signed-in-name"),
  logoutButton: document.querySelector("#logout-button"),
  taskControls: document.querySelector("#task-controls"),
  taskRegion: document.querySelector("#task-list-region")
};

function setFlashMessage(message, isError = false) {
  elements.flash.textContent = message;
  elements.flash.style.color = isError ? "var(--danger)" : "var(--accent-2)";
}

function syncFilterUi() {
  elements.filterChips.forEach((chip) => chip.classList.toggle("is-active", chip.dataset.status === filters.status));
}

function showSession() {
  const signedIn = session.token !== null;
  elements.loginForm.hidden = signedIn;
  elements.signedIn.hidden = !signedIn;
  elements.taskControls.hidden = !signedIn;
  elements.taskRegion.hidden = !signedIn;
  elements.signedInName.textContent = session.username ?? "";
}

function signOut(message = "Signed out.") {
  session.token = null;
  session.username = null;
  sessionStorage.removeItem("task-tracker-session");
  showSession();
  setFlashMessage(message);
}

function startSession(result) {
  session.token = result.access_token;
  session.username = result.username;
  sessionStorage.setItem("task-tracker-session", JSON.stringify(session));
  elements.loginPassword.value = "";
  showSession();
}

async function refresh() {
  if (session.token === null) return;
  try {
    const tasks = await service.list();
    const visibleTasks = applyFilters(tasks, filters);
    renderSummary(elements.summary, summarizeTasks(tasks));
    renderTaskList(elements.taskList, visibleTasks);
    syncFilterUi();
  } catch (error) {
    if (error instanceof UnauthorizedError) return signOut("Your session ended. Please sign in again.");
    setFlashMessage(error.message || "Could not refresh tasks.", true);
  }
}

elements.loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    startSession(await signIn(elements.loginUsername.value, elements.loginPassword.value));
    setFlashMessage(`Welcome, ${session.username}.`);
    await refresh();
  } catch (error) {
    setFlashMessage(error.message, true);
  }
});

elements.registerButton.addEventListener("click", async () => {
  try {
    await register(elements.loginUsername.value, elements.loginPassword.value);
    startSession(await signIn(elements.loginUsername.value, elements.loginPassword.value));
    setFlashMessage(`Account created. Welcome, ${session.username}.`);
    await refresh();
  } catch (error) {
    setFlashMessage(error.message, true);
  }
});

elements.logoutButton.addEventListener("click", () => signOut());

elements.quickAddForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await service.create({ title: elements.titleInput.value, priority: elements.priorityInput.value, dueDate: elements.dueInput.value || null });
    elements.titleInput.value = "";
    elements.dueInput.value = "";
    setFlashMessage("Task added.");
    await refresh();
  } catch (error) {
    setFlashMessage(error.message || "Could not add task.", true);
  }
});

elements.searchInput.addEventListener("input", async (event) => {
  filters.search = event.target.value;
  await refresh();
});

for (const chip of elements.filterChips) {
  chip.addEventListener("click", async () => { filters.status = chip.dataset.status; await refresh(); });
}

elements.taskList.addEventListener("change", async (event) => {
  const card = event.target.closest("[data-task-id]");
  if (!card) return;
  try {
    if (event.target.dataset.action === "toggle-done") {
      await service.toggleDone(card.dataset.taskId);
      setFlashMessage("Updated task status.");
    }
    if (event.target.dataset.action === "priority-change") {
      await service.setPriority(card.dataset.taskId, event.target.value);
      setFlashMessage("Updated priority.");
    }
    if (event.target.dataset.action === "due-change") {
      await service.setDueDate(card.dataset.taskId, event.target.value || null);
      setFlashMessage("Updated due date.");
    }
    await refresh();
  } catch (error) {
    setFlashMessage(error.message || "Could not update task.", true);
  }
});

elements.taskList.addEventListener("click", async (event) => {
  const button = event.target.closest('[data-action="clear-due"]');
  if (!button) return;
  const card = button.closest("[data-task-id]");
  try {
    await service.setDueDate(card.dataset.taskId, null);
    setFlashMessage("Cleared due date.");
    await refresh();
  } catch (error) {
    setFlashMessage(error.message || "Could not clear the due date.", true);
  }
});

elements.overdueOnly.addEventListener("change", async () => {
  filters.overdueOnly = elements.overdueOnly.checked;
  await refresh();
});

try {
  Object.assign(session, JSON.parse(sessionStorage.getItem("task-tracker-session")) ?? {});
} catch {
  // A missing or unreadable saved session just means signing in again.
}
showSession();
refresh();
