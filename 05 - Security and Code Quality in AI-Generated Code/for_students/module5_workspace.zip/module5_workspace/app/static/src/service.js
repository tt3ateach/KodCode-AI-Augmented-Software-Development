// Preserve the Module 3 service seam. The client sends the signed-in user's token with every request.
import { createWorkItemsApiClient } from "./apiClient.js";
export function createTaskService(getToken) { return createWorkItemsApiClient("", fetch, getToken); }
