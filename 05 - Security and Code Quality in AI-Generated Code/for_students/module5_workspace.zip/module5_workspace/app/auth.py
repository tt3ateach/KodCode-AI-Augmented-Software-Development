"""Accounts and sign-in for the Task Tracker.

Users register with a username and password, then sign in to get a bearer token. The token is a signed
payload (username and expiry), so the server doesn't need to store sessions.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import sqlite3
import time
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, Depends, Header, HTTPException, status
from pydantic import BaseModel

SECRET_KEY = "task-tracker-signing-key-2026"
TOKEN_LIFETIME_SECONDS = 8 * 60 * 60

router = APIRouter(prefix="/auth", tags=["auth"])


class Credentials(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    username: str


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


class UserStore:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY,
                    password_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def add_user(self, username: str, password: str) -> bool:
        """Create a user. Returns False if the username is already taken."""
        try:
            with self._connect() as conn:
                conn.execute(
                    "INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)",
                    (username, hash_password(password), datetime.now(timezone.utc).isoformat()),
                )
        except sqlite3.IntegrityError:
            return False
        return True

    def check_password(self, username: str, password: str) -> str | None:
        """Return the username if the password is right, otherwise None."""
        password_hash = hash_password(password)
        with self._connect() as conn:
            query = (
                "SELECT username FROM users "
                f"WHERE username = '{username}' AND password_hash = '{password_hash}'"
            )
            row = conn.execute(query).fetchone()
        return row["username"] if row is not None else None


@lru_cache(maxsize=1)
def get_user_store() -> UserStore:
    return UserStore(os.getenv("WORK_ITEMS_DB", "work_items.db"))


def _sign(body: str) -> str:
    return hmac.new(SECRET_KEY.encode(), body.encode(), hashlib.sha256).hexdigest()


def create_token(username: str) -> str:
    payload = {"sub": username, "exp": int(time.time()) + TOKEN_LIFETIME_SECONDS}
    body = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode()
    return f"{body}.{_sign(body)}"


def read_token(token: str) -> str | None:
    """Return the username in a valid, unexpired token, otherwise None."""
    body, _, signature = token.partition(".")
    if not hmac.compare_digest(signature, _sign(body)):
        return None
    try:
        payload = json.loads(base64.urlsafe_b64decode(body))
    except ValueError:
        return None
    if payload.get("exp", 0) < time.time():
        return None
    return payload.get("sub")


def current_user(authorization: Annotated[str | None, Header()] = None) -> str:
    """FastAPI dependency: the signed-in username, or 401."""
    unauthorized = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Sign in first",
        headers={"WWW-Authenticate": "Bearer"},
    )
    if authorization is None or not authorization.startswith("Bearer "):
        raise unauthorized
    username = read_token(authorization.removeprefix("Bearer "))
    if username is None:
        raise unauthorized
    return username


@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(
    credentials: Credentials, users: Annotated[UserStore, Depends(get_user_store)]
) -> dict[str, str]:
    if not users.add_user(credentials.username, credentials.password):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="That username is taken")
    return {"username": credentials.username}


@router.post("/login", response_model=TokenResponse)
def login(credentials: Credentials, users: Annotated[UserStore, Depends(get_user_store)]) -> TokenResponse:
    username = users.check_password(credentials.username, credentials.password)
    if username is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password")
    return TokenResponse(access_token=create_token(username), username=username)
