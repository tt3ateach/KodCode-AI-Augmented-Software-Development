# Module 5 · Security and code quality in AI-generated code · steps

Copy from here. Commands run in the VS Code terminal; prompts go to Copilot Chat in **Agent mode**.
- **New chat:** start a fresh chat (the + button) before that step, so earlier answers don't carry over.
- **Keep:** after an edit you approved, click Keep in the chat before you go on.
- Keep the current step at the top of this file: later steps give answers away.

## Ready

**1.** In the terminal, check that everything runs. It also resets the demo users. Expected: `Ready for class.`
```
python scripts/check_setup.py
```

## Why this matters

**2.** Start the app, open http://127.0.0.1:8000/ and sign in as `alice` with the password `alice-password`.
Then click Sign out. Leave the app running.
```
python -m uvicorn app.main:app --port 8000
```

**3.** Sign in again, with this username and the password `anything`:
```
' OR 1=1 --
```
Sign out, and try the username `bob' --`. Sign out again, then stop the app in the terminal with Ctrl+C.

**4.** Instructor only, can skip. New chat. Prompt:
```
Don't read or change any file in this workspace. In the chat only, write a minimal FastAPI register and
login API backed by SQLite, using only the Python standard library for password hashing and tokens.
Keep it under 60 lines.
```

## Review by hand

**5.** Open `app/auth.py` and `app/main.py`. For each question, write down the file and line of anything you find:
1. **Input to queries:** where does user input reach an SQL query? Is it passed as a parameter?
2. **Secrets:** is any key, password or token written in the code?
3. **Passwords:** what rules must a new password follow, and how is it stored?
4. **Ownership:** does every endpoint that takes a task id check that the task belongs to the signed-in user?

## The scanner

**6.** Run Bandit, a static analysis tool for Python, on the app. Each line is one finding: file and line,
rule, severity/confidence, message.
```
python -m bandit -r app -q -f custom --msg-template "{relpath}:{line}  {test_id}  {severity}/{confidence}  {msg}"
```

## The AI review

**7.** New chat. Prompt:
```
Review app/auth.py and app/main.py for security problems. For each problem, give the file and line, what
an attacker could do, and how to fix it. List at most six, most serious first. Do not edit files.
```

## Test, fix, check

**8.** Your test. Paste it at the end of `tests/test_security.py`:
```python
def test_bob_cannot_change_alices_task(api):
    alice = sign_in(api, "alice", "alice-password")
    bob = sign_in(api, "bob", "bob-password")
    task = api.post("/work-items", json={"title": "Alice's task"}, headers=alice).json()
    path = "/work-items/" + task["id"]

    response = api.patch(path, json={"title": "Changed by Bob"}, headers=bob)

    assert response.status_code in (403, 404)
    assert api.get(path, headers=alice).json()["title"] == "Alice's task"
```

**9.** Run it:
```
python -m pytest -q tests/test_security.py
```

**10.** New chat. Prompt:
```
Our review of app/auth.py and app/main.py found four problems:
1. The login query is built from user input (SQL injection).
2. The token signing key is written in the code.
3. Passwords have no rules and are stored as unsalted SHA-256.
4. A signed-in user can read, change or delete another user's task by its id.
Propose the smallest fix for each: a parameterized query; the key from the environment variable
TASK_TRACKER_SECRET_KEY (the app must still start without it); passwords of 8 to 128 characters, hashed
with hashlib.scrypt (n=2**14, r=8, p=1) and a random salt per user; owner checks that answer 404.
No new dependencies. Do not change the tests. Show the changes and wait for approval.
```

**11.** Prompt, after reading the proposal. Then click Keep:
```
Go ahead.
```
If the assistant is slow: `git restore --source fixed app`

**12.** Run everything, then the scanner again (no output from Bandit means no findings):
```
python -m pytest -q
python -m bandit -r app -q -f custom --msg-template "{relpath}:{line}  {test_id}  {severity}/{confidence}  {msg}"
```

**13.** The team's security checks, one test per finding (your test from step 8 is the first one):
```
git restore --source fixed tests/test_security.py
python -m pytest -q tests/test_security.py
```
If one fails, that's what the fix missed. To catch up: `git restore --source fixed app`

**14.** Try the attack again. Start the app, reload the page (sign out if it still shows you signed in), and sign in
as `' OR 1=1 --`. Then sign in as `alice` / `alice-password`:
```
python -m uvicorn app.main:app --port 8000
```
If alice can't sign in either, stop the app (Ctrl+C), reset the demo users, and start it again:
```
python scripts/demo_data.py
```
