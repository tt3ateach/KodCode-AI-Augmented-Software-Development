"""Check that this workspace is ready for class. Run it from the workspace folder:

    python scripts/check_setup.py

It also resets the demo users (alice and bob) and their tasks.
"""

from __future__ import annotations

import importlib.util
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PACKAGES = ("fastapi", "uvicorn", "pytest", "httpx", "bandit")


def report(ok: bool, message: str) -> bool:
    print(("OK    " if ok else "FAIL  ") + message)
    return ok


def run(*command: str) -> subprocess.CompletedProcess:
    return subprocess.run(list(command), cwd=ROOT, capture_output=True, text=True)


def check_git() -> bool:
    try:
        tag = run("git", "rev-parse", "--verify", "--quiet", "fixed^{commit}")
    except FileNotFoundError:
        return report(False, "Git isn't installed. Install it from https://git-scm.com, then reopen VS Code.")
    if tag.returncode != 0:
        return report(False, "No Git history here. Unzip module5_workspace.zip again, with its .git folder.")
    return report(True, "Git and the workspace's history")


def main() -> int:
    ok = report(sys.version_info >= (3, 10), f"Python {sys.version.split()[0]} (3.10 or newer)")
    missing = [name for name in PACKAGES if importlib.util.find_spec(name) is None]
    if missing:
        ok = report(False, f"Missing {', '.join(missing)}. Run: python -m pip install -r requirements.lock")
    else:
        report(True, "Packages installed")
    if not ok:
        return 1
    ok &= check_git()
    tests = run(sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider")
    summary = (tests.stdout.strip().splitlines() or ["no output"])[-1]
    ok &= report(tests.returncode == 0, "Tests: " + re.sub(r"=+", "", summary).strip())
    demo = run(sys.executable, str(ROOT / "scripts" / "demo_data.py"))
    ok &= report(demo.returncode == 0, demo.stdout.strip() or demo.stderr.strip().splitlines()[-1])
    print("\nReady for class." if ok else "\nSomething is missing. Send the lines above to your instructor.")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
