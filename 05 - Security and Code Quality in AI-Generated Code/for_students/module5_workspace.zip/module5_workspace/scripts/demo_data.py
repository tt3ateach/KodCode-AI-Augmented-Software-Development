"""Create the class demo data: users alice and bob, each with a few tasks.

Run it from the workspace folder: python scripts/demo_data.py
It rebuilds the users and tasks tables in work_items.db, so it also works after a fix changes them.
Run it again whenever you want a fresh start.
"""

from __future__ import annotations

import os
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.auth import UserStore  # noqa: E402
from app.models import WorkItemCreate  # noqa: E402
from app.repository import SQLiteWorkItemRepository  # noqa: E402

DEMO_USERS = {
    "alice": ("alice-password", ["Prepare the Q4 roadmap", "Review the payments pull request"]),
    "bob": ("bob-password", ["Rotate the staging database password", "Book the team offsite"]),
}


def main() -> None:
    db_path = Path(os.getenv("WORK_ITEMS_DB", ROOT / "work_items.db"))
    with sqlite3.connect(db_path) as conn:
        conn.execute("DROP TABLE IF EXISTS work_items")
        conn.execute("DROP TABLE IF EXISTS users")
    repository = SQLiteWorkItemRepository(db_path)
    users = UserStore(db_path)
    for username, (password, titles) in DEMO_USERS.items():
        users.add_user(username, password)
        for title in titles:
            repository.create_item(WorkItemCreate(title=title, priority="high"), owner=username)
    print(f"Demo data ready in {db_path.name}: alice / alice-password and bob / bob-password.")


if __name__ == "__main__":
    main()
