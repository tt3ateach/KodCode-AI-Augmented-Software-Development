# Task F part 1: write the clock test here.
# Replace only app.main.server_now (for example with pytest's monkeypatch) and call the real
# app.main.get_reference_date().
