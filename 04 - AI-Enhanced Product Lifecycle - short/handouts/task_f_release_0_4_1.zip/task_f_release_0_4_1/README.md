# Work Items 0.4.1 · Task F (25 minutes) · Copilot Agent mode

This is the release from the support thread. All 34 tests that shipped with 0.4.1 pass. Your job is to write
the test that should have existed.

**Minimum:** a test that fails on 0.4.1, the fix, one mutation result, and an answer to the question:
why did the 34 shipped tests pass?

## Before you start (2 minutes)
Open this folder as your VS Code workspace, select the class interpreter as in your Student Guide, and
commit the starting point:
```bash
git init
git add -A
git commit -m start
```

## Part 1 · The missing test (15 minutes)
1. In `tests/test_clock_provider.py`, write a test that replaces only `server_now` with a fixed instant,
   2026-10-04 00:30 at UTC+03:00, and calls the real `get_reference_date()`. The contract (REQ-04) gives
   the expected day. If you want the assistant's help, have it propose the test, read it, then approve it:
   ```text
   Read docs/feature_contract.md (REQ-04) and app/main.py. Propose a pytest test for
   tests/test_clock_provider.py that calls the real get_reference_date() with only server_now replaced by
   2026-10-04 00:30 at UTC+03:00, and asserts the day REQ-04 requires. Show it and wait for approval.
   ```
   ```text
   Go ahead: write it to tests/test_clock_provider.py, replacing the placeholder. Then stop: don't run it
   and don't change app code.
   ```
2. Run `python -m pytest -q tests/test_clock_provider.py`. On 0.4.1 the test should fail.
   If it passes, check what your fixtures replace.
3. Make the smallest fix in `app/main.py` (you saw the change that broke it in class). Then run the full
   suite with `python -m pytest -q`.

Still stuck at minute 10? Ask your instructor for the worked test.

## Part 2 · Mutation check (8 minutes)
1. In `app/overdue.py`, change `<` to `<=`. Run `python -m pytest -q`.
2. Record which tests fail, and explain why your clock test does or doesn't fail.
3. Restore the line and run the suite again.
